'use client';
import { useSession, signIn } from 'next-auth/react';
import { useEffect, useState, useCallback, useMemo } from 'react';
import Link from 'next/link';

// ───── 유틸 ─────
// 매출/마진/예상매출 등 금액은 백만원 단위 표기 (반올림)
function won(n) {
  if (n === null || n === undefined || isNaN(Number(n))) return '-';
  const num = Number(n);
  if (num === 0) return '0백만원';
  const m = Math.round(num / 1_000_000);
  return m.toLocaleString('ko-KR') + '백만원';
}
// 원 단위까지 보고싶을 때 (리스트 안 등)
function wonFull(n) {
  if (n === null || n === undefined || isNaN(Number(n))) return '-';
  return Number(n).toLocaleString('ko-KR') + '원';
}
function count(n) {
  if (n === null || n === undefined || isNaN(Number(n))) return '-';
  return Number(n).toLocaleString('ko-KR') + '건';
}
function pct(n) {
  if (n === null || n === undefined || isNaN(Number(n))) return '-';
  return Number(n).toLocaleString('ko-KR', { maximumFractionDigits: 1 }) + '%';
}

function Spinner({ size = 16, color = '#2563eb' }) {
  return (
    <span style={{
      display: 'inline-block', width: size, height: size,
      border: `2px solid ${color}33`, borderTopColor: color,
      borderRadius: '50%', animation: 'wkd-spin 0.8s linear infinite',
      verticalAlign: 'middle',
    }} />
  );
}

function LoadingRow({ size = 16, text = '데이터 가져오는 중...' }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8, color: '#6b7280', fontSize: 13 }}>
      <Spinner size={size} />
      <span>{text}</span>
    </div>
  );
}

// ───── 디자인 옵션 E — 기간 카드 ─────
// variant: 'now' | 'future' | 'past' | 'reference'
// target: 목표 매출 (있으면 예상매출 대신 표시)
function PeriodCard({ title, data, loading, error, range, variant = 'past', target = null }) {
  const styles = {
    now: {
      bg: 'linear-gradient(135deg, #2563eb 0%, #7c3aed 100%)',
      color: '#fff', shadow: '0 4px 14px rgba(37,99,235,0.3)',
      labelOp: 0.85, subOp: 0.75,
      badge: 'NOW', badgeBg: '#fff', badgeColor: '#2563eb',
      progressTrack: 'rgba(255,255,255,0.25)', progressFill: '#fff',
      borderColor: 'transparent',
    },
    future: {
      bg: '#fff', color: '#111', shadow: '0 1px 3px rgba(0,0,0,0.06)',
      border: '2px dashed #c084fc', labelOp: 1, subOp: 1,
      badge: '예정', badgeBg: '#c084fc', badgeColor: '#fff',
      progressTrack: '#f3f4f6', progressFill: 'linear-gradient(90deg, #2563eb, #7c3aed)',
      borderColor: '#e5e7eb',
    },
    past: {
      bg: '#f9fafb', color: '#374151', shadow: 'none',
      border: '1px solid #e5e7eb', labelOp: 1, subOp: 1,
      progressTrack: '#e5e7eb', progressFill: '#6b7280',
      borderColor: '#e5e7eb',
    },
    reference: {
      bg: 'linear-gradient(135deg, #0891b2 0%, #06b6d4 100%)',
      color: '#fff', shadow: '0 4px 14px rgba(8,145,178,0.25)',
      labelOp: 0.85, subOp: 0.75,
      progressTrack: 'rgba(255,255,255,0.25)', progressFill: '#fff',
      borderColor: 'transparent',
    },
  };
  const s = styles[variant];

  // 진행률: target이 있으면 mixed/target, 없으면 mixed/estimated
  const ref = target !== null ? target : (data?.estimatedSales || 0);
  const refLabel = target !== null ? '목표 매출' : '예상 매출';
  const pct = ref > 0 ? ((data?.mixedSales || 0) / ref) * 100 : 0;
  const onWhite = variant === 'now' || variant === 'reference';

  return (
    <div style={{
      position: 'relative',
      padding: 20, borderRadius: 14,
      background: s.bg, color: s.color,
      boxShadow: s.shadow,
      border: s.border || 'none',
      transition: 'transform 0.15s',
    }}>
      {s.badge && (
        <div style={{
          position: 'absolute', top: -10, right: 16,
          background: s.badgeBg, color: s.badgeColor,
          padding: '3px 12px', borderRadius: 14,
          fontSize: 11, fontWeight: 700,
          boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
        }}>{s.badge}</div>
      )}

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 12 }}>
        <div style={{ fontSize: 15, fontWeight: 700 }}>📅 {title}</div>
        {range && <div style={{ fontSize: 11, opacity: s.subOp }}>{range.startDate} ~ {range.endDate}</div>}
      </div>

      {loading ? (
        <LoadingRow size={14} text="로딩 중..." />
      ) : error ? (
        <div style={{ fontSize: 12, color: onWhite ? 'rgba(255,255,255,0.95)' : '#ef4444' }}>로드 실패</div>
      ) : (
        <>
          <div style={{ marginBottom: 12 }}>
            <div style={{ fontSize: 12, opacity: s.labelOp, marginBottom: 4 }}>예상매출 + 실제매출</div>
            <div style={{ fontSize: 26, fontWeight: 800, lineHeight: 1 }}>{won(data?.mixedSales)}</div>
          </div>

          <div style={{ marginBottom: 12 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11, marginBottom: 4, opacity: s.labelOp }}>
              <span>{refLabel} {won(ref)}</span>
              <span style={{ fontWeight: 600 }}>{pct.toFixed(0)}%</span>
            </div>
            <div style={{ height: 6, background: s.progressTrack, borderRadius: 3, overflow: 'hidden' }}>
              <div style={{
                width: `${Math.min(pct, 100)}%`, height: '100%',
                background: s.progressFill, borderRadius: 3,
              }} />
            </div>
          </div>

          <div style={{
            fontSize: 12, opacity: s.subOp, paddingTop: 10,
            borderTop: `1px solid ${onWhite ? 'rgba(255,255,255,0.2)' : '#e5e7eb'}`,
          }}>
            🛒 공구마켓 <strong>{count(data?.marketsAll)}</strong> (진행 {count(data?.marketsActive)})
          </div>
        </>
      )}
    </div>
  );
}

// ───── 셀러/브랜드 리스트 (검색 + 필터) ─────
function ListCard({ title, emoji, rows, loading, columns, sortOptions, range }) {
  const [search, setSearch] = useState('');
  const [sortBy, setSortBy] = useState(sortOptions[0].value);

  const filtered = useMemo(() => {
    if (!rows) return [];
    const q = search.trim().toLowerCase();
    const arr = q
      ? rows.filter(r => {
          const hay = [
            r.name || '',
            r.manager || '',
            r.managerName || '',
            r.sellerName || '',
            r.brandName || '',
            ...(r.brands || []),
            ...(r.sellers || []),
          ].join(' ').toLowerCase();
          return hay.includes(q);
        })
      : rows;

    return [...arr].sort((a, b) => {
      const av = a[sortBy] || 0;
      const bv = b[sortBy] || 0;
      return bv - av;
    });
  }, [rows, search, sortBy]);

  return (
    <section style={card}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 12 }}>
        <div>
          <h2 style={{ fontSize: 16, margin: 0, fontWeight: 600 }}>
            {emoji} {title} <span style={{ fontSize: 12, color: '#9ca3af', fontWeight: 400 }}>({filtered.length}개)</span>
          </h2>
          {range && <div style={{ fontSize: 11, color: '#9ca3af', marginTop: 2 }}>{range.startDate} ~ {range.endDate}</div>}
        </div>
      </div>

      <div style={{ display: 'flex', gap: 8, marginBottom: 12, flexWrap: 'wrap' }}>
        <input
          type="text"
          placeholder="🔎 이름/담당자 검색"
          value={search}
          onChange={e => setSearch(e.target.value)}
          style={{
            padding: '8px 12px', fontSize: 13, flex: 1, minWidth: 200,
            border: '1px solid #d1d5db', borderRadius: 6,
          }}
        />
        <div style={{ display: 'flex', gap: 4, alignItems: 'center' }}>
          <span style={{ fontSize: 12, color: '#6b7280' }}>정렬:</span>
          {sortOptions.map(o => (
            <button key={o.value} onClick={() => setSortBy(o.value)} style={sortBtn(sortBy === o.value)}>
              {o.label}
            </button>
          ))}
        </div>
      </div>

      {loading ? (
        <LoadingRow text="목록 가져오는 중..." />
      ) : filtered.length === 0 ? (
        <p style={{ fontSize: 13, color: '#9ca3af', textAlign: 'center', padding: 20 }}>
          {search ? '검색 결과 없음' : '데이터 없음'}
        </p>
      ) : (
        <div style={{ overflowX: 'auto', maxHeight: 600, overflowY: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
            <thead style={{ position: 'sticky', top: 0, background: '#f9fafb', zIndex: 1 }}>
              <tr>
                <th style={{ ...th, textAlign: 'left', width: 40 }}>#</th>
                {columns.map(c => (
                  <th key={c.key} style={{ ...th, textAlign: c.align || 'right' }}>{c.label}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((r, i) => (
                <tr key={r.name}>
                  <td style={{ ...td, textAlign: 'left', color: '#9ca3af' }}>{i + 1}</td>
                  {columns.map(c => (
                    <td key={c.key} style={{ ...td, textAlign: c.align || 'right' }}>
                      {c.render ? c.render(r) : (r[c.key] ?? '-')}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}

function ManagerList({ rows, loading, range }) {
  return (
    <section style={card}>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 12 }}>
        <h2 style={{ fontSize: 16, margin: 0, fontWeight: 600 }}>👤 이번달 담당자별 매출</h2>
        {range && <div style={{ fontSize: 11, color: '#9ca3af' }}>{range.startDate} ~ {range.endDate}</div>}
      </div>
      {loading ? (
        <LoadingRow text="목록 가져오는 중..." />
      ) : !rows || rows.length === 0 ? (
        <p style={{ fontSize: 13, color: '#9ca3af' }}>데이터 없음</p>
      ) : (
        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
          <thead>
            <tr style={{ background: '#f9fafb' }}>
              <th style={{ ...th, textAlign: 'left', width: 40 }}>#</th>
              <th style={{ ...th, textAlign: 'left' }}>담당자</th>
              <th style={th}>매출</th>
              <th style={th}>마진</th>
              <th style={th}>고객(중복제거)</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r, i) => (
              <tr key={r.name}>
                <td style={{ ...td, textAlign: 'left', color: '#9ca3af' }}>{i + 1}</td>
                <td style={{ ...td, textAlign: 'left', fontWeight: 500 }}>{r.name}</td>
                <td style={td}>{won(r.sales)}</td>
                <td style={td}>{won(r.margin)}</td>
                <td style={td}>{count(r.uniqueCustomers)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </section>
  );
}

// ───── 메인 페이지 ─────
const PERIODS = [
  { key: 'thisYear', title: '올해 누적', isFull: false },
  { key: 'thisQuarter', title: '이번 분기', isFull: false },
  { key: 'thisMonth', title: '이번달', isFull: true }, // 셀러/브랜드 리스트도 가져옴
  { key: 'nextMonth', title: '다음달', isFull: false },
  { key: 'thisWeek', title: '이번주', isFull: false },
  { key: 'nextWeek', title: '다음주', isFull: false },
  { key: 'lastMonth', title: '저번달', isFull: false },
  { key: 'sameMonthLastYear', title: '전년 동월', isFull: false },
];

// 목표 매출 (단위: 원)
const YEAR_TARGET = 20_000_000_000;     // 200억
const QUARTER_TARGET = 5_000_000_000;   // 50억

export default function QueryPage() {
  const { data: session, status } = useSession();
  const [summaries, setSummaries] = useState({});

  useEffect(() => {
    if (!session) return;

    PERIODS.forEach(p => {
      const qs = p.isFull ? `?period=${p.key}&full=true` : `?period=${p.key}`;
      fetch('/api/summary' + qs)
        .then(r => r.json())
        .then(d => setSummaries(prev => ({ ...prev, [p.key]: d })))
        .catch(e => setSummaries(prev => ({ ...prev, [p.key]: { error: e.message } })));
    });
  }, [session]);

  if (status === 'loading') return <main style={{ padding: 40 }}>로딩 중...</main>;
  if (!session) {
    return (
      <main style={{ padding: 40, maxWidth: 480, margin: '80px auto', textAlign: 'center' }}>
        <h1 style={{ fontSize: 28 }}>로그인 필요</h1>
        <button onClick={() => signIn('google')} style={{
          padding: '12px 24px', fontSize: 16, background: '#4285F4', color: '#fff',
          border: 'none', borderRadius: 8, cursor: 'pointer',
        }}>Google 계정으로 로그인</button>
      </main>
    );
  }

  const tokenExpired = Object.values(summaries).some(d => d?.ordersError?.includes('EXPIRED') || d?.marketsError?.includes('EXPIRED') || d?.message?.includes('EXPIRED'));

  const thisMonth = summaries.thisMonth;

  return (
    <main style={{ padding: 24, maxWidth: 1400, margin: '0 auto', background: '#f9fafb', minHeight: '100vh' }}>
      <style>{`@keyframes wkd-spin { to { transform: rotate(360deg); } }`}</style>

      <header style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
        <div>
          <h1 style={{ fontSize: 22, margin: 0 }}>🔎 매출 조회기</h1>
          <p style={{ fontSize: 12, color: '#9ca3af', margin: '4px 0 0' }}>기본 요약 + 셀러/브랜드 검색</p>
        </div>
        <Link href="/" style={{ fontSize: 13, color: '#2563eb', textDecoration: 'none' }}>← 대시보드로</Link>
      </header>

      {tokenExpired && (
        <div style={{
          padding: '12px 16px', marginBottom: 16,
          background: '#fef3c7', border: '1px solid #fcd34d', borderRadius: 8,
          fontSize: 13, color: '#92400e',
        }}>
          ⚠️ 와이어드민 토큰이 만료됐어요. 새 토큰 발급 필요.
        </div>
      )}

      <div style={{
        padding: '10px 14px', marginBottom: 16,
        background: '#eff6ff', border: '1px solid #bfdbfe', borderRadius: 8,
        fontSize: 12, color: '#1e40af', display: 'flex', flexWrap: 'wrap', gap: 16,
      }}>
        <span><strong>📊 매출:</strong> 와이어드민 주문 결제금액 합 (배송비 포함)</span>
        <span><strong>📅 기간 기준:</strong> 발송일</span>
        <span><strong>💡 예상매출:</strong> 마켓 등록 시 입력값 (단위: 백만원 × {(1_000_000).toLocaleString()})</span>
        <span><strong>🔄 갱신:</strong> 매일 새벽 3시 + 페이지 진입</span>
      </div>

      {/* ─── 기본 요약 ─── */}
      <h2 style={sectionH}>📌 매출 한눈에</h2>

      {/* 1행: 올해 누적 / 이번 분기 (목표 매출 기준) */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginBottom: 14 }}>
        <PeriodCard
          title="올해 누적"
          data={summaries.thisYear}
          loading={!summaries.thisYear}
          error={summaries.thisYear?.error}
          range={summaries.thisYear?.range}
          variant="reference"
          target={YEAR_TARGET}
        />
        <PeriodCard
          title="이번 분기"
          data={summaries.thisQuarter}
          loading={!summaries.thisQuarter}
          error={summaries.thisQuarter?.error}
          range={summaries.thisQuarter?.range}
          variant="reference"
          target={QUARTER_TARGET}
        />
      </div>

      {/* 2행: 이번달 / 다음달 */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginBottom: 14 }}>
        <PeriodCard
          title="이번달"
          data={summaries.thisMonth}
          loading={!summaries.thisMonth}
          error={summaries.thisMonth?.error || summaries.thisMonth?.ordersError}
          range={summaries.thisMonth?.range}
          variant="now"
        />
        <PeriodCard
          title="다음달"
          data={summaries.nextMonth}
          loading={!summaries.nextMonth}
          error={summaries.nextMonth?.error}
          range={summaries.nextMonth?.range}
          variant="future"
        />
      </div>

      {/* 3행: 이번주 / 다음주 */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginBottom: 14 }}>
        <PeriodCard
          title="이번주"
          data={summaries.thisWeek}
          loading={!summaries.thisWeek}
          error={summaries.thisWeek?.error}
          range={summaries.thisWeek?.range}
          variant="now"
        />
        <PeriodCard
          title="다음주"
          data={summaries.nextWeek}
          loading={!summaries.nextWeek}
          error={summaries.nextWeek?.error}
          range={summaries.nextWeek?.range}
          variant="future"
        />
      </div>

      {/* 4행: 저번달 / 전년동월 */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginBottom: 24 }}>
        <PeriodCard
          title="저번달"
          data={summaries.lastMonth}
          loading={!summaries.lastMonth}
          error={summaries.lastMonth?.error}
          range={summaries.lastMonth?.range}
          variant="past"
        />
        <PeriodCard
          title="전년 동월"
          data={summaries.sameMonthLastYear}
          loading={!summaries.sameMonthLastYear}
          error={summaries.sameMonthLastYear?.error}
          range={summaries.sameMonthLastYear?.range}
          variant="past"
        />
      </div>

      {/* ─── 마켓 리스트 ─── */}
      <h2 style={sectionH}>🛒 이번달 마켓</h2>
      <ListCard
        title="마켓 전체"
        emoji=""
        loading={!thisMonth || !thisMonth.marketsList}
        rows={thisMonth?.marketsList}
        range={thisMonth?.range}
        sortOptions={[
          { value: 'actualSales', label: '매출' },
          { value: 'orderCount', label: '주문건수' },
          { value: 'estimatedSales', label: '예상매출' },
          { value: 'achievementRate', label: '달성률' },
        ]}
        columns={[
          { key: 'name', label: '마켓명', align: 'left' },
          { key: 'sellerName', label: '셀러', align: 'left' },
          { key: 'brandName', label: '브랜드', align: 'left' },
          { key: 'managerName', label: '담당자', align: 'left' },
          { key: 'status', label: '상태', align: 'left', render: r => {
            const map = { READY: '예정', ACTIVE: '진행중', ENDED: '종료', CANCELED: '취소' };
            const colorMap = { READY: '#3b82f6', ACTIVE: '#10b981', ENDED: '#6b7280', CANCELED: '#ef4444' };
            return <span style={{ color: colorMap[r.status] || '#6b7280', fontSize: 12, fontWeight: 500 }}>{map[r.status] || r.status}</span>;
          }},
          { key: 'actualSales', label: '매출', render: r => won(r.actualSales) },
          { key: 'orderCount', label: '주문건수\n(중복제거)', render: r => count(r.orderCount) },
          { key: 'estimatedSales', label: '예상매출', render: r => won(r.estimatedSales) },
          { key: 'achievementRate', label: '달성률', render: r => {
            const v = r.achievementRate;
            if (v === null || v === undefined) return '-';
            const color = v >= 100 ? '#10b981' : v >= 80 ? '#f59e0b' : '#ef4444';
            return <span style={{ color, fontWeight: 600 }}>{pct(v)}</span>;
          }},
        ]}
      />

      <div style={{ height: 16 }} />

      {/* ─── 셀러 리스트 ─── */}
      <h2 style={sectionH}>🏪 이번달 셀러</h2>
      <ListCard
        title="셀러 전체"
        emoji=""
        loading={!thisMonth || !thisMonth.sellers}
        rows={thisMonth?.sellers}
        range={thisMonth?.range}
        sortOptions={[
          { value: 'actualSales', label: '매출' },
          { value: 'uniqueCustomers', label: '주문건수' },
          { value: 'estimatedSales', label: '예상매출' },
          { value: 'achievementRate', label: '달성률' },
        ]}
        columns={[
          { key: 'name', label: '셀러명', align: 'left' },
          { key: 'manager', label: '담당자', align: 'left' },
          { key: 'actualSales', label: '매출', render: r => won(r.actualSales) },
          { key: 'uniqueCustomers', label: '주문건수\n(중복제거)', render: r => count(r.uniqueCustomers) },
          { key: 'estimatedSales', label: '예상매출', render: r => won(r.estimatedSales) },
          { key: 'achievementRate', label: '달성률', render: r => {
            const v = r.achievementRate;
            if (v === null || v === undefined) return '-';
            const color = v >= 100 ? '#10b981' : v >= 80 ? '#f59e0b' : '#ef4444';
            return <span style={{ color, fontWeight: 600 }}>{pct(v)}</span>;
          }},
        ]}
      />

      <div style={{ height: 16 }} />

      {/* ─── 브랜드 리스트 ─── */}
      <h2 style={sectionH}>🏷️ 이번달 브랜드</h2>
      <ListCard
        title="브랜드 전체"
        emoji=""
        loading={!thisMonth || !thisMonth.brands}
        rows={thisMonth?.brands}
        range={thisMonth?.range}
        sortOptions={[
          { value: 'actualSales', label: '매출' },
          { value: 'uniqueCustomers', label: '주문건수' },
          { value: 'estimatedSales', label: '예상매출' },
          { value: 'achievementRate', label: '달성률' },
        ]}
        columns={[
          { key: 'name', label: '브랜드명', align: 'left' },
          { key: 'sellers', label: '셀러', align: 'left', render: r => (r.sellers || []).slice(0, 3).join(', ') + ((r.sellers?.length || 0) > 3 ? '...' : '') },
          { key: 'actualSales', label: '매출', render: r => won(r.actualSales) },
          { key: 'uniqueCustomers', label: '주문건수\n(중복제거)', render: r => count(r.uniqueCustomers) },
          { key: 'estimatedSales', label: '예상매출', render: r => won(r.estimatedSales) },
          { key: 'achievementRate', label: '달성률', render: r => {
            const v = r.achievementRate;
            if (v === null || v === undefined) return '-';
            const color = v >= 100 ? '#10b981' : v >= 80 ? '#f59e0b' : '#ef4444';
            return <span style={{ color, fontWeight: 600 }}>{pct(v)}</span>;
          }},
        ]}
      />

      <div style={{ height: 16 }} />

      {/* ─── 담당자 ─── */}
      <ManagerList
        rows={thisMonth?.bySellerManager}
        loading={!thisMonth || !thisMonth.bySellerManager}
        range={thisMonth?.range}
      />
    </main>
  );
}

// ───── styles ─────
const sectionH = { fontSize: 18, margin: '8px 0 12px', fontWeight: 700, color: '#111' };
const card = {
  padding: 20, background: '#fff',
  border: '1px solid #e5e7eb', borderRadius: 12,
  boxShadow: '0 1px 3px rgba(0,0,0,0.04)',
};
const summaryCard = {
  padding: 16, background: '#fff',
  border: '1px solid #e5e7eb', borderRadius: 10,
};
const th = {
  padding: '10px 8px', borderBottom: '2px solid #e5e7eb',
  fontSize: 12, color: '#6b7280', fontWeight: 500, whiteSpace: 'pre-line',
};
const td = {
  padding: '8px 8px', borderBottom: '1px solid #f3f4f6', fontSize: 13,
};
function sortBtn(active) {
  return {
    padding: '6px 10px', fontSize: 12,
    background: active ? '#2563eb' : '#fff',
    color: active ? '#fff' : '#374151',
    border: '1px solid ' + (active ? '#2563eb' : '#d1d5db'),
    borderRadius: 5, cursor: 'pointer',
  };
}
